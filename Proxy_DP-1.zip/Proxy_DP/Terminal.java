public interface Terminal {
    public void run(String command, String user);
}
